package com.techm.user.entity;

public class ChartData {

	private String key;
	private String value;
	
	public ChartData() {
		
	}

	public ChartData(String count, String date) {
		super();
		this.key = count;
		this.value = date;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "ChartData [key=" + key + ", value=" + value + "]";
	}

	
	
	

}

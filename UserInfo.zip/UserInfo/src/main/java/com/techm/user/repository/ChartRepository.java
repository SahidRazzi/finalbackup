package com.techm.user.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.techm.user.entity.ChartData;

@Repository
public class ChartRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<ChartData> getChartData() {
		
		
		List<ChartData> appuser = jdbcTemplate.query(

				"select (created_at::timestamp::date) as date, count(created_at) as user_count from techm_user group by (created_at::timestamp::date)",

				new ResultSetExtractor<List<ChartData>>() {

					@Override
					public List<ChartData> extractData(ResultSet rs) throws SQLException, DataAccessException {

						List<ChartData> chartData = new ArrayList<ChartData>();

						while (rs.next()) {

							ChartData e = new ChartData(rs.getString("date"), rs.getString("user_count") );
                            chartData.add(e);

						}

						return chartData;

					}

				});

		return appuser;

	}
}

package com.techm.user.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.techm.user.entity.ChartData;
import com.techm.user.entity.User;

@Service
public interface UserService {
	
	public List<User> getUsers();
	public User getUser(String email);
	public User saveOrUpdateUser(User user);
	public void deleteUser(User user);
	public List<ChartData> getChartMeta();

}

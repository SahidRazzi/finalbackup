package com.techm.user.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.techm.user.entity.ChartData;
import com.techm.user.entity.User;
import com.techm.user.repository.ChartRepository;
import com.techm.user.repository.UserRepositiry;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	ChartRepository repository;

	@Autowired
	UserRepositiry userRepository;

	@Override
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User getUser(String email) {
		// TODO Auto-generated method stub
		return userRepository.findByEmail(email);
	}

	@Override
	public User saveOrUpdateUser(User entity) {
		return userRepository.save(entity);

	}

	@Override
	public void deleteUser(User entity) {
		// TODO Auto-generated method stub
		userRepository.delete(entity);
	}

	@Override
	public List<ChartData> getChartMeta() {
		// TODO Auto-generated method stub
		return repository.getChartData();
	}
}

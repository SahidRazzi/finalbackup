package com.techm.user.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.techm.user.entity.ChartData;
import com.techm.user.entity.User;
import com.techm.user.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;

	@GetMapping("/")
	public String userLogin(Model model) {
		model.addAttribute("user", new User());
		return "login";
	}

	@GetMapping("/userlist")
	public String redirect(Model model) {
		model.addAttribute("users", userService.getUsers());
		return "userlist";
	}

	@GetMapping("/signup")
	public String registration(Model model) {
		model.addAttribute("user", new User());
		return "register";
	}

	@GetMapping("/update-info")
	public String updateUserInfo(Model model) {
		model.addAttribute("user", new User());
		return "personal-info";
	}

	@GetMapping("/upload")
	public String uploadFile() {
		return "fileupload";
	}

	@PostMapping("/saveFile")
	public String saveFile(@RequestParam("file") MultipartFile file, Model model, HttpSession httpSession) {
		User user = userService.getUser((String) httpSession.getAttribute("userName"));
		try {
			byte[] b = file.getBytes();
			System.out.println(b);
			user.setFile(b);
			user.setFileName(file.getName());
			userService.saveOrUpdateUser(user);
		} catch (IOException e) {

			return "fileupload";
		}
		System.out.println(file.getName());
		model.addAttribute("user", user);
		return "personal-info";
	}

	@PostMapping("/getUser")
	public ResponseEntity<User> getUser(@ModelAttribute("user") User user) {
		return new ResponseEntity<User>(userService.getUser(user.getEmail()), HttpStatus.OK);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<User>> findAllUser() {
		return new ResponseEntity<List<User>>(userService.getUsers(), HttpStatus.OK);
	}

	@GetMapping("/linechart")
	public String lineChart(Model model) {
		System.out.println("Data" + userService.getChartMeta());
		model.addAttribute("chartData", userService.getChartMeta());
		return "linechart";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveUser(@Valid @ModelAttribute("user") User user, BindingResult result, Model model,
			HttpSession session) {
		User persistedUser;
		session.setAttribute("userName", user.getEmail());
		if (result.hasErrors()) {
			model.addAttribute("message",
					"password must contain minimum 8 chars, 1 special symbol, lowercase and uppercase");
			model.addAttribute("error", result);
			System.out.println("error result" + result.getFieldError());
			return "register";
		}

		try {
			persistedUser = userService.saveOrUpdateUser(user);

		} catch (Exception e) {
			model.addAttribute("message", "user name already exist");
			return "register";
		}

		model.addAttribute("user", persistedUser);
		return "personal-info";
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String updateUser(@ModelAttribute("user") User user, Model model) {
		System.out.println("User" + user.getUserId());
		userService.saveOrUpdateUser(user);
		model.addAttribute("message", "User information updated succesfully");
		return "dashboard";
	}

	@PostMapping("/validate")
	public String isValidUser(@ModelAttribute("user") User user, HttpSession httpSession, Model model) {
		User existinguser = userService.getUser(user.getEmail());

		if (existinguser != null) {

			httpSession.setAttribute("userName", user.getEmail());

			if (existinguser.getEmail().equals(user.getEmail())
					&& existinguser.getPassword().equals(user.getPassword())) {
				model.addAttribute("message", "Login in successfully");

				return "dashboard";
			}
		}
		model.addAttribute("message", "Username or password is incorrect");
		return "login";

	}

}
